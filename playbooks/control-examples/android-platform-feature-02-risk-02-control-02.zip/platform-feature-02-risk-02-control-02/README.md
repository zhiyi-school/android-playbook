# platform-feature-02-risk-02-control-02

This is a minimal Android app that redacts sensitive data before it is written to Logcat.

## Implemented Controls

- Routes logging through `SecureLogger`, which matches email addresses, card numbers, NRIC numbers and passwords with regular expressions.
- Replaces matches with placeholders such as `[REDACTED_EMAIL]` before calling `android.util.Log`.

Enter synthetic values, tap Submit and filter Logcat by the `SecureApp` tag to confirm every value is redacted. Pattern matching only catches formats it knows, so avoid logging sensitive values in the first place.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
