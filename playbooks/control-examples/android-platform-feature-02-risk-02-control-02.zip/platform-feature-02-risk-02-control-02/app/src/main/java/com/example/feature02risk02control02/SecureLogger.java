package com.example.feature02risk02control02;

import android.util.Log;

public final class SecureLogger {
    private static final String[][] PII_PATTERNS = {
        {"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", "[REDACTED_EMAIL]"},
        {"\\b\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}\\b", "[REDACTED_CARD]"},
        {"[STFGM]\\d{7}[A-Z]", "[REDACTED_NRIC]"},
        {"(?i)(password|pwd|pass)[=:\"'\\s]+[^\\s,\"']+", "[REDACTED_PASSWORD]"}
    };

    private SecureLogger() {}

    private static String sanitize(String message) {
        if (message == null) return "[null]";
        String result = message;
        for (String[] pattern : PII_PATTERNS) {
            result = result.replaceAll(pattern[0], pattern[1]);
        }
        return result;
    }

    public static void d(String tag, String msg) { Log.d(tag, sanitize(msg)); }
    public static void i(String tag, String msg) { Log.i(tag, sanitize(msg)); }
    public static void e(String tag, String msg) { Log.e(tag, sanitize(msg)); }
    public static void v(String tag, String msg) { Log.v(tag, sanitize(msg)); }
    public static void w(String tag, String msg) { Log.w(tag, sanitize(msg)); }
}
