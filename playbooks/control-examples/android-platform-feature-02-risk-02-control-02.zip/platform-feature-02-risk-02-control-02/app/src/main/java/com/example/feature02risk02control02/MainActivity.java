package com.example.feature02risk02control02;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String TAG = "SecureApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById(android.R.id.content).setFitsSystemWindows(true);

        EditText emailInput = findViewById(R.id.emailInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        EditText creditCardInput = findViewById(R.id.creditCardInput);
        EditText nricInput = findViewById(R.id.nricInput);

        Button submitBtn = findViewById(R.id.submitButton);
        submitBtn.setOnClickListener(v -> {
            String email = emailInput.getText().toString();
            String password = passwordInput.getText().toString();
            String creditCard = creditCardInput.getText().toString();
            String nric = nricInput.getText().toString();

            // Same logging as VulnerableApp, but using SecureLogger
            // PII is automatically redacted before reaching Logcat
            SecureLogger.d(TAG, "User email: " + email);
            SecureLogger.d(TAG, "Password: " + password);
            SecureLogger.i(TAG, "Credit card: " + creditCard);
            SecureLogger.d(TAG, "NRIC: " + nric);

            Toast.makeText(this, "Check Logcat - PII is redacted!", Toast.LENGTH_SHORT).show();
        });
    }
}
