# platform-feature-05-risk-03-control-01

This is a minimal Android app that hides sensitive on-screen text from accessibility services.

## Implemented Controls

- Sets `android:importantForAccessibility="noHideDescendants"` on the balance and transactions containers, hiding them and all their child views from accessibility services that use default settings.

This does not block screenshots taken with `GLOBAL_ACTION_TAKE_SCREENSHOT`; use `FLAG_SECURE` (android-platform-feature-06-risk-01-control-01) for that. Also test against a service that sets `flagIncludeNotImportantViews`. Hidden views are not read by TalkBack.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
