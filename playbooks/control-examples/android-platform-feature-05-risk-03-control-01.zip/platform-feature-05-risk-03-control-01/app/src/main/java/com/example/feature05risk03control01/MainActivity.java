package com.example.feature05risk03control01;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // The control is applied in res/layout/activity_main.xml.
        setContentView(R.layout.activity_main);
    }
}
