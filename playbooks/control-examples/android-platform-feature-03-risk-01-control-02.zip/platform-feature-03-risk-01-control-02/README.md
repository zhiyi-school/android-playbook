# platform-feature-03-risk-01-control-02

This is a minimal Android app that refuses to run while an HTTP proxy or VPN is active.

## Implemented Controls

- Checks `ConnectivityManager.getDefaultProxy()` and `ProxySelector` for a configured proxy.
- Checks the active network for a VPN transport.
- Runs the checks on launch and in `onResume()`, and shows a non-cancellable alert whose only button terminates the app.

Filter Logcat by the `ProxyDetector` tag to see which check fired. Detection runs on the device and can be bypassed with hooking, so combine it with certificate pinning (control-01).

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
