package com.example.feature03risk01control02;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.ProxyInfo;
import android.os.Build;
import android.util.Log;

import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.util.List;

public final class ProxyDetector {

    private static final String TAG = "ProxyDetector";

    private ProxyDetector() {}

    public static boolean isProxyDetected(Context context) {
        return isProxySetViaConnectivityManager(context)
                || isProxySetViaProxySelector()
                || isVpnActive(context);
    }

    public static boolean isProxySetViaConnectivityManager(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                ConnectivityManager cm = (ConnectivityManager)
                        context.getSystemService(Context.CONNECTIVITY_SERVICE);

                if (cm != null) {
                    Network activeNetwork = cm.getActiveNetwork();
                    if (activeNetwork != null) {
                        // Get proxy info for active network
                        ProxyInfo proxyInfo = cm.getDefaultProxy();
                        if (proxyInfo != null) {
                            String host = proxyInfo.getHost();
                            int port = proxyInfo.getPort();
                            if (host != null && !host.isEmpty()) {
                                Log.w(TAG, "Proxy detected via ConnectivityManager: " +
                                        host + ":" + port);
                                return true;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error checking ConnectivityManager: " + e.getMessage());
            }
        }
        return false;
    }

    public static boolean isProxySetViaProxySelector() {
        try {
            List<Proxy> proxies = ProxySelector.getDefault().select(new URI("https://www.google.com"));
            for (Proxy proxy : proxies) {
                if (proxy.type() != Proxy.Type.DIRECT) {
                    Log.w(TAG, "Proxy detected via ProxySelector: " + proxy.address());
                    return true;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking ProxySelector: " + e.getMessage());
        }
        return false;
    }

    public static boolean isVpnActive(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                ConnectivityManager cm = (ConnectivityManager)
                        context.getSystemService(Context.CONNECTIVITY_SERVICE);

                if (cm != null) {
                    Network activeNetwork = cm.getActiveNetwork();
                    if (activeNetwork != null) {
                        NetworkCapabilities caps = cm.getNetworkCapabilities(activeNetwork);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                            Log.w(TAG, "VPN connection detected");
                            return true;
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error checking VPN: " + e.getMessage());
            }
        }
        return false;
    }
}
