package com.example.feature03risk01control02;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView text = new TextView(this);
        text.setPadding(48, 48, 48, 48);
        text.setText("No proxy detected. App is running normally.");
        setContentView(text);
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById(android.R.id.content).setFitsSystemWindows(true);

        checkForProxy();
    }

    // Re-check when the user returns, in case a proxy was set while the app was in the background.
    @Override
    protected void onResume() {
        super.onResume();
        checkForProxy();
    }

    private void checkForProxy() {
        if (ProxyDetector.isProxyDetected(this)) {
            showProxyDialog();
        }
    }

    private void showProxyDialog() {
        if (dialog != null && dialog.isShowing()) return;
        // Critical control: non-cancellable dialog whose only action exits the app.
        dialog = new AlertDialog.Builder(this)
                .setTitle("Proxy Detected")
                .setMessage("Network traffic is being routed through a proxy or VPN. Disable it to use this app.")
                .setCancelable(false)
                .setPositiveButton("Exit", (d, which) -> {
                    finishAffinity();
                    android.os.Process.killProcess(android.os.Process.myPid());
                })
                .show();
    }
}
