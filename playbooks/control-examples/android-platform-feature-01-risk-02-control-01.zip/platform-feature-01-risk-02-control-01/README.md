# platform-feature-01-risk-02-control-01

This is a minimal Android app that detects repackaging by checking its signing certificate at runtime.

## Implemented Controls

- Calculates the SHA-256 hash of the signing certificate in `onCreate()` before any other initialisation.
- Compares it to a hardcoded expected value.
- Shows a non-cancellable dialog that terminates the app when the hashes do not match.

## Demo signing key

Debug and release builds are both signed with `app/demo-signing.keystore`, a demo-only key included in the project, and `EXPECTED_SIGNATURE_HASH` is set to its SHA-256 fingerprint. Verification therefore passes as soon as you run the app. Filter Logcat by `System.out` to see the actual and expected hashes.

To see the tamper dialog, re-sign the APK with any other key, for example:

```bash
apksigner sign --ks ~/.android/debug.keystore --ks-pass pass:android --out tampered.apk app/build/outputs/apk/debug/app-debug.apk
adb install -r tampered.apk
```

In a real app, set `EXPECTED_SIGNATURE_HASH` to your signing certificate's fingerprint. With Play App Signing, use the app signing key fingerprint from Play Console.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
