package com.example.feature01risk02control01;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import androidx.appcompat.app.AlertDialog;

import java.security.MessageDigest;

public final class SignatureVerification {

    // SHA-256 fingerprint of the signing certificate (app/demo-signing.keystore).
    // With Play App Signing, use the app signing key fingerprint from Play Console instead.
    private static final String EXPECTED_SIGNATURE_HASH = "BE6BDF13C6DBB8831B7B697CE69C98A7D4DDE494352194A92154B26572AFE9DE";

    private SignatureVerification() {}

    public static boolean verifySignature(Activity activity) {
        try {
            PackageInfo packageInfo = activity.getPackageManager().getPackageInfo(
                    activity.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            Signature[] signatures = packageInfo.signingInfo.getApkContentsSigners();
            if (signatures.length == 0) {
                return false;
            }
            for (Signature signature : signatures) {
                if (!verifySignatureHash(signature)) {
                    return false;
                }
            }
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private static boolean verifySignatureHash(Signature signature) {
        try {
            // Get the raw certificate bytes
            byte[] signatureBytes = signature.toByteArray();

            // Calculate SHA-256 hash
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(signatureBytes);

            // Convert hash bytes to hexadecimal string
            String actualHash = bytesToHex(hashBytes);

            // Log for debugging (remove in production or obfuscate)
            System.out.println("====================================");
            System.out.println("CERTIFICATE SIGNATURE VERIFICATION");
            System.out.println("====================================");
            System.out.println("Actual SHA-256: " + actualHash);
            System.out.println("Expected SHA-256: " + EXPECTED_SIGNATURE_HASH);

            // Compare with expected hash
            boolean isValid = actualHash.equalsIgnoreCase(EXPECTED_SIGNATURE_HASH);
            System.out.println("Signature Valid: " + isValid);
            System.out.println("====================================");

            return isValid;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    /**
     * Non-cancellable dialog: the only way out is to terminate the app.
     */
    public static void showTamperDialog(Activity activity) {
        new AlertDialog.Builder(activity)
                .setTitle("Integrity Verification Failed")
                .setMessage("This app has been modified or repackaged and cannot be used. Please install the official version.")
                .setCancelable(false)
                .setPositiveButton("Exit", (dialog, which) -> {
                    activity.finishAffinity();
                    System.exit(0);
                })
                .show();
    }
}
