package com.example.feature01risk02control01;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // CONTROL FX02-C01: Signature verification MUST be first thing in onCreate()
        // This runs before any other initialization to prevent tampered apps from executing
        if (!SignatureVerification.verifySignature(this)) {
            // Signature mismatch detected - app has been repackaged/tampered
            SignatureVerification.showTamperDialog(this);
            // Dialog will terminate app when user clicks "Exit"
            return; // Stop further initialization
        }

        // If we reach here, signature is valid - continue normal app flow
        initializeApp();
    }

    /**
     * Normal app initialization after signature verification passes.
     */
    private void initializeApp() {
        TextView statusText = findViewById(R.id.statusText);
        statusText.setText("✓ Signature verification passed!\n\nThis app is authentic and has not been modified.");
    }
}
