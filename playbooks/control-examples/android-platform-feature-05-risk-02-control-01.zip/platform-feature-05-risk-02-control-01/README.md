# platform-feature-05-risk-02-control-01

This is a minimal Android app that hides its sign-in fields from accessibility services.

## Implemented Controls

- Sets `android:importantForAccessibility="no"` on the username and password `TextInputLayout`s, their `TextInputEditText`s and the login button, so accessibility services using default settings do not receive their events or node information.

A service that sets `flagIncludeNotImportantViews` still receives these views, so test against such a service. Hiding sign-in fields also stops TalkBack from reading them. On Android 14 (API level 34) and later, `android:accessibilityDataSensitive="yes"` is an alternative that keeps the views available to TalkBack.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
