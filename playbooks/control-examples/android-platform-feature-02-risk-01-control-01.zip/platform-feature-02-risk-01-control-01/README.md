# platform-feature-02-risk-01-control-01

This is a minimal Android app that encrypts sensitive data before writing it to the private data directory.

## Implemented Controls

- Generates a 256-bit AES key inside the Android Keystore so the key material never appears in the app's files.
- Encrypts values with AES-256-GCM and stores `Base64(IV)]Base64(ciphertext)` in SharedPreferences.
- Decrypts only when the value is needed.

Verify by opening `/data/data/com.example.feature02risk01control01/shared_prefs/user_data.xml` in Device Explorer and confirming it contains ciphertext.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
