package com.example.feature02risk01control01;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class CryptoManager {

    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String KEY_ALIAS = "secure_prefs_key";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final String SEPARATOR = "]";
    private static final int GCM_TAG_LENGTH = 128;

    public String encrypt(String plaintext) throws Exception {
        if (plaintext == null || plaintext.isEmpty()) {
            return "";
        }

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());

        // Encrypt the data
        byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

        // Get the IV (Initialization Vector)
        byte[] iv = cipher.getIV();

        // Combine IV and encrypted data
        // Format: Base64(IV) + SEPARATOR + Base64(Ciphertext)
        String ivString = Base64.encodeToString(iv, Base64.DEFAULT);
        String encryptedString = Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
        return ivString + SEPARATOR + encryptedString;
    }

    public String decrypt(String encryptedData) throws Exception {
        if (encryptedData == null || encryptedData.isEmpty()) {
            return "";
        }

        // Split back into IV and ciphertext
        String[] parts = encryptedData.split(SEPARATOR);
        byte[] iv = Base64.decode(parts[0], Base64.DEFAULT);
        byte[] encryptedBytes = Base64.decode(parts[1], Base64.DEFAULT);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(GCM_TAG_LENGTH, iv));
        return new String(cipher.doFinal(encryptedBytes), StandardCharsets.UTF_8);
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);

        // Reuse the key if it was created on an earlier run.
        SecretKey existing = (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        if (existing != null) {
            return existing;
        }

        // Otherwise create a 256-bit AES key inside the Android Keystore.
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build();

        KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
        keyGenerator.init(spec);
        return keyGenerator.generateKey();
    }
}
