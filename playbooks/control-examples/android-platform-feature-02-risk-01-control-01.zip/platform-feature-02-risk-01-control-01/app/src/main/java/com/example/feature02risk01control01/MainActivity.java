package com.example.feature02risk01control01;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private final CryptoManager cryptoManager = new CryptoManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);

        EditText input = new EditText(this);
        input.setHint("Sensitive value, e.g. NRIC");
        Button save = new Button(this);
        save.setText("Save encrypted");
        Button load = new Button(this);
        load.setText("Load");
        TextView status = new TextView(this);

        save.setOnClickListener(v -> {
            try {
                // Only ciphertext is written to shared_prefs/user_data.xml.
                prefs.edit().putString("nric", cryptoManager.encrypt(input.getText().toString())).apply();
                input.setText("");
                status.setText("Saved. Inspect shared_prefs/user_data.xml in Device Explorer to see ciphertext.");
            } catch (Exception e) {
                status.setText("Encryption failed: " + e.getMessage());
            }
        });
        load.setOnClickListener(v -> {
            try {
                status.setText("Decrypted: " + cryptoManager.decrypt(prefs.getString("nric", "")));
            } catch (Exception e) {
                status.setText("Decryption failed: " + e.getMessage());
            }
        });

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 48, 48, 48);
        layout.addView(input);
        layout.addView(save);
        layout.addView(load);
        layout.addView(status);
        setContentView(layout);
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById(android.R.id.content).setFitsSystemWindows(true);
    }
}
