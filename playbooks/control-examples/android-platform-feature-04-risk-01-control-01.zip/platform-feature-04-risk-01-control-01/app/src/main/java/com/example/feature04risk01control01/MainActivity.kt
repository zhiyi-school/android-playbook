package com.example.feature04risk01control01

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            setPadding(48, 48, 48, 48)
            text = "Overlay windows from other apps are hidden while this screen is in the foreground."
        })
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById<android.view.View>(android.R.id.content).fitsSystemWindows = true
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            window.setHideOverlayWindows(true)
        }
    }
}
