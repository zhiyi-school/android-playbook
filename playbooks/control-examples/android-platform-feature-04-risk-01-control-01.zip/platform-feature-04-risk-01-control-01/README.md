# platform-feature-04-risk-01-control-01

This is a minimal Android app that hides overlay windows drawn by other apps.

## Implemented Controls

- Declares `android.permission.HIDE_OVERLAY_WINDOWS` in `AndroidManifest.xml`.
- Calls `window.setHideOverlayWindows(true)` in `onResume()` on Android 12 (API level 31) and later.

Verify by running an app that draws a `TYPE_APPLICATION_OVERLAY` window, then opening this app and confirming the overlay disappears. The playbook shows this inside a React Native `ReactActivity`. This project uses a plain `Activity` so it builds without React Native; the `onResume()` code is the same.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
