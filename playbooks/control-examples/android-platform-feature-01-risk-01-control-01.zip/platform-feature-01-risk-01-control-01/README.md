# platform-feature-01-risk-01-control-01

This is a minimal Android app that makes reverse engineering harder.

## Implemented Controls

- Enables R8 (`minifyEnabled`, `shrinkResources`) for the release build so classes, methods and fields are renamed to short, meaningless names.
- Signs the release build with `app/release.keystore`, a demo-only key included so the release build installs straight away. Use your own key in a real app, and never sign debug builds with it.
- Stores the playbook's example value (`sk_live_1234567890abcdef`, not a real key) as an XOR-obfuscated byte array in `ApiKeyProvider`, so it does not appear in simple string searches or MobSF's hardcoded-secrets report.

To see the obfuscation, build and install the release variant (`./gradlew installRelease`, or select the `release` build variant in Android Studio), then open `app/build/outputs/apk/release/app-release.apk` in jadx and compare it with the debug APK.

XOR is obfuscation, not encryption: the key is in the same APK. Secret keys, such as payment `sk_live_` keys, must stay on the server.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
