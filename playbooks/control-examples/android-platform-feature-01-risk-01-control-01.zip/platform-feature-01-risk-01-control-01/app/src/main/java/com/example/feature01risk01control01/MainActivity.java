package com.example.feature01risk01control01;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView text = new TextView(this);
        text.setPadding(48, 48, 48, 48);
        text.setText("API key decoded at runtime (" + ApiKeyProvider.getApiKey().length() + " characters).\n\n"
                + "Open the release APK in jadx to see obfuscated class and method names.");
        setContentView(text);
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById(android.R.id.content).setFitsSystemWindows(true);
    }
}
