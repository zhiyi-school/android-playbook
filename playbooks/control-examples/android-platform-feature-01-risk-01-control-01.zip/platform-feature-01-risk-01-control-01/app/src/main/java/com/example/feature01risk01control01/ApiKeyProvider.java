package com.example.feature01risk01control01;

public final class ApiKeyProvider {

    private static final byte[] KEY = {
        0x5A, 0x3B, 0x48, 0x15, 0x4A, 0x31, 0x60, 0x3F,
        0x0A, 0x3A, 0x7E, 0x15, 0x4F, 0x20, 0x6F, 0x57,
        0x02, 0x3A, 0x2E, 0x4A, 0x10, 0x78, 0x60, 0x0B
    };

    private ApiKeyProvider() {}

    public static String getApiKey() {
        // Encrypted bytes of "sk_live_1234567890abcdef"
        byte[] encrypted = {
            0x29, 0x50, 0x17, 0x79, 0x23, 0x47, 0x05, 0x60,
            0x3B, 0x08, 0x4D, 0x21, 0x7A, 0x16, 0x58, 0x6F,
            0x3B, 0x0A, 0x4F, 0x28, 0x73, 0x1C, 0x05, 0x6D
        };
        return decrypt(encrypted);
    }

    /**
     * XOR decryption - reverses the encryption
     */
    private static String decrypt(byte[] encrypted) {
        byte[] decrypted = new byte[encrypted.length];
        for (int i = 0; i < encrypted.length; i++) {
            decrypted[i] = (byte) (encrypted[i] ^ KEY[i % KEY.length]);
        }
        return new String(decrypted);
    }
}
