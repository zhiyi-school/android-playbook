# platform-feature-02-risk-02-control-01

This is a minimal Android app that refuses to run while USB debugging is enabled.

## Implemented Controls

- Reads `Settings.Global.ADB_ENABLED` in `onCreate()` and `onResume()`.
- Shows a non-cancellable alert whose only button terminates the app.

The dialog is the Jetpack Compose `BlockedByAdbDialog()` from the playbook. Because USB debugging is usually on while you install from Android Studio, expect the dialog on first launch. Turn off USB debugging in Developer options and reopen the app to see it run normally.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
