package com.example.feature02risk02control01

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private val adbEnabled = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adbEnabled.value = isAdbEnabled()
        setContent {
            MaterialTheme {
                if (adbEnabled.value) {
                    BlockedByAdbDialog()
                } else {
                    Text(
                        "USB debugging is off. App is running normally.",
                        modifier = Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp)
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-check in case USB debugging was turned on while the app was in the background
        adbEnabled.value = isAdbEnabled()
    }

    private fun isAdbEnabled(): Boolean {
        return try {
            android.provider.Settings.Global.getInt(
                contentResolver,
                android.provider.Settings.Global.ADB_ENABLED
            ) == 1
        } catch (e: Exception) {
            false
        }
    }
}

@Composable
fun BlockedByAdbDialog() {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { /* Do nothing → prevents cancellation */ },
        title = {
            Text("USB Debugging Enabled")
        },
        text = {
            Text("Please turn off USB debugging before using this app.")
        },
        confirmButton = {
            // Exit button
            androidx.compose.material3.TextButton(
                onClick = {
                    // exits the app
                    android.os.Process.killProcess(android.os.Process.myPid())
                }) {
                Text("Exit")
            }
        }
    )
}
