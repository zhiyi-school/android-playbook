# platform-feature-03-risk-01-control-01

This is a minimal Android app that pins the server's public key with OkHttp's `CertificatePinner`.

## Implemented Controls

- Pins the SHA-256 public key hashes of `httpbin.org`'s current certificate chain (leaf, Amazon RSA 2048 M01 intermediate and Amazon Root CA 1, as of October 2026). A connection succeeds if any one pin matches, so the CA pins keep working when the leaf certificate is renewed.
- Rejects any TLS connection whose certificate chain does not contain a pinned key, so requests are never sent through an intercepting proxy such as Burp Suite.
- Shows a warning when pinning fails.

Pins go stale when the server changes CA. List the current chain's pins with:

```bash
openssl s_client -connect httpbin.org:443 -servername httpbin.org -showcerts </dev/null 2>/dev/null \
  | awk '/BEGIN CERT/{n++} {print > ("cert" n ".pem")}'
for c in cert[1-9]*.pem; do
  openssl x509 -in "$c" -pubkey -noout | openssl pkey -pubin -outform der | openssl dgst -sha256 -binary | base64
done
```

When verifying, make Burp's CA a trusted system CA. With only a user-installed CA the connection fails even without pinning.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
