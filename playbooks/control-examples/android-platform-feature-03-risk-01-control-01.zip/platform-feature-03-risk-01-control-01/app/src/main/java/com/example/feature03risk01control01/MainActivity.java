package com.example.feature03risk01control01;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;

import javax.net.ssl.SSLPeerUnverifiedException;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends Activity {
    private static final CertificatePinner certificatePinner = new CertificatePinner.Builder()
            .add("httpbin.org", "sha256/AxBkYmhbMwxqUkEu7yx5FyIaTOfXqiqMYahybvzFxfw=")
            .add("httpbin.org", "sha256/DxH4tt40L+eduF6szpY6TONlxhZhBd+pJ9wbHlQ2fuw=")
            .add("httpbin.org", "sha256/++MBgDH5WGvL9Bcn5Be30cRcL0f5O+NyoXuWtQdX1aI=")
            .build();

    private final OkHttpClient client = new OkHttpClient.Builder()
            .certificatePinner(certificatePinner)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView status = new TextView(this);
        status.setPadding(48, 48, 48, 48);
        status.setText("Connecting to https://httpbin.org/get ...");
        setContentView(status);
        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById(android.R.id.content).setFitsSystemWindows(true);

        new Thread(() -> {
            String result;
            boolean pinFailed = false;
            Request request = new Request.Builder().url("https://httpbin.org/get").build();
            try (Response response = client.newCall(request).execute()) {
                result = "Connected. HTTP " + response.code() + "\nCertificate matched the pinned hash.";
            } catch (SSLPeerUnverifiedException e) {
                // The connection is rejected before any request data is sent.
                result = "Certificate pinning failure.\n\n" + e.getMessage();
                pinFailed = true;
            } catch (Exception e) {
                result = "Connection failed: " + e.getMessage();
            }
            String text = result;
            boolean showWarning = pinFailed;
            runOnUiThread(() -> {
                status.setText(text);
                if (showWarning) {
                    new AlertDialog.Builder(this)
                            .setTitle("Untrusted Connection")
                            .setMessage("The server certificate does not match. The request was blocked.")
                            .setCancelable(false)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }).start();
    }
}
