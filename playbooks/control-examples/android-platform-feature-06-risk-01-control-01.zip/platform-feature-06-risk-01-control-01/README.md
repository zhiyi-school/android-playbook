# platform-feature-06-risk-01-control-01

This is a minimal Android app that blocks its content from screenshots and screen recordings.

## Implemented Controls

- Sets `FLAG_SECURE` on the activity window in `onCreate()`.
- Sets `FLAG_SECURE` on the dialog window too, because dialogs, popups and bottom sheets open in separate windows that do not inherit it.

Verify by starting a screen recording and opening both the main screen and the dialog; both should appear black. The playbook shows this inside a React Native `ReactActivity` (with Expo's `setTheme(R.style.AppTheme)` and `super.onCreate(null)`). This project uses a plain `Activity` so it builds without React Native; the `FLAG_SECURE` call is the same.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
