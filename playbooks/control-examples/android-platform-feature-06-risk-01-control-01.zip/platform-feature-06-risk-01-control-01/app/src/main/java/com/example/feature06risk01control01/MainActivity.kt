package com.example.feature06risk01control01

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        super.onCreate(savedInstanceState)

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(TextView(this@MainActivity).apply { text = "Account balance: $12,345.67" })
            addView(Button(this@MainActivity).apply {
                text = "Show card details"
                setOnClickListener { showCardDialog() }
            })
        })

        // Keep content clear of the system bars (edge-to-edge is enforced from Android 15).
        findViewById<android.view.View>(android.R.id.content).fitsSystemWindows = true
    }

    // Dialogs open in a separate window that does not inherit FLAG_SECURE, so set it on that window too.
    private fun showCardDialog() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Card details")
            .setMessage("4111 1111 1111 1111\nExp 12/30")
            .setPositiveButton("Close", null)
            .create()
        dialog.window?.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        dialog.show()
    }
}
