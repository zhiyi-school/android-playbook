# platform-feature-07-risk-01-control-01

This is a minimal Android app that encrypts PII before writing it to `files/pii.json`, so root access to the private data directory only reveals ciphertext.

## Implemented Controls

- Generates a 256-bit AES key inside the Android Keystore.
- Encrypts the JSON with AES-256-GCM and writes `IV (12 bytes) || ciphertext+tag` to `pii.json`.

Verify on a rooted device after tapping Save PII:

```bash
adb shell "su -c 'cat /data/data/com.demo.protectedapp/files/pii.json'"
```

The output should be unreadable binary rather than JSON. Root can still use the app's own Keystore key at runtime by hooking the app, so this protects data at rest rather than against a live attacker on the device.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
