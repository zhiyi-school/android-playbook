package com.example.feature05risk01control01

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt

class DashboardActivity : AppCompatActivity() {

    private lateinit var biometricAuthManager: BiometricAuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        biometricAuthManager = BiometricAuthManager(this)
        observeBiometricResults()

        findViewById<Button>(R.id.btn_logout).setOnClickListener { handleLogoutClick() }
    }

    /**
     * Handle logout button click
     * Initiates biometric authentication or falls back to dialog
     */
    private fun handleLogoutClick() {
        if (biometricAuthManager.isBiometricAvailable()) {
            // Device has biometric - require biometric for logout
            initiateLogoutBiometricAuth()
        } else {
            // Fallback: Show traditional confirmation dialog
            showLogoutConfirmation()
        }
    }

    /**
     * Initiate biometric authentication for logout verification
     */
    private fun initiateLogoutBiometricAuth() {
        biometricAuthManager.authenticate(
            activity = this,
            title = "Confirm Logout",
            subtitle = "Verify your identity to logout",
            description = "Use your biometric to confirm you want to logout"
        )
    }

    /**
     * Observe biometric authentication results for logout
     */
    private fun observeBiometricResults() {
        biometricAuthManager.authenticationResult.observe(this) { result ->
            when (result) {
                is BiometricAuthManager.BiometricAuthResult.Success -> {
                    Toast.makeText(
                        this,
                        "Logout confirmed",
                        Toast.LENGTH_SHORT
                    ).show()
                    performLogout()
                }

                is BiometricAuthManager.BiometricAuthResult.Failure -> {
                    Toast.makeText(
                        this,
                        "Biometric verification failed: ${result.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                is BiometricAuthManager.BiometricAuthResult.Error -> {
                    handleBiometricError(result.errorCode, result.errorMessage)
                }
            }
        }
    }

    private fun handleBiometricError(errorCode: Int, errorMessage: String) {
        // Cancelling the prompt is not an error worth reporting
        if (errorCode == BiometricPrompt.ERROR_USER_CANCELED || errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
            return
        }
        Toast.makeText(this, "Biometric error: $errorMessage", Toast.LENGTH_SHORT).show()
    }

    private fun showLogoutConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Confirm Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ -> performLogout() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performLogout() {
        findViewById<TextView>(R.id.tv_status).text = "Logged out."
        findViewById<Button>(R.id.btn_logout).isEnabled = false
    }
}
