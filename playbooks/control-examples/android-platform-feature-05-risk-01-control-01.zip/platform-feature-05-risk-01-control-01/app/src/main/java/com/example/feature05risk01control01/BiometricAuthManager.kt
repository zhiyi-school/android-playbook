package com.example.feature05risk01control01

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class BiometricAuthManager(private val context: Context) {

    sealed class BiometricAuthResult {
        object Success : BiometricAuthResult()
        data class Failure(val message: String) : BiometricAuthResult()
        data class Error(val errorCode: Int, val errorMessage: String) : BiometricAuthResult()
    }

    private val _authenticationResult = MutableLiveData<BiometricAuthResult>()
    val authenticationResult: LiveData<BiometricAuthResult> = _authenticationResult

    fun isBiometricAvailable(): Boolean =
        BiometricManager.from(context).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    fun authenticate(activity: FragmentActivity, title: String, subtitle: String, description: String) {
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setDescription(description)
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel")
            .build()

        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    _authenticationResult.value = BiometricAuthResult.Success
                }

                override fun onAuthenticationFailed() {
                    _authenticationResult.value = BiometricAuthResult.Failure("Biometric not recognised")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    _authenticationResult.value = BiometricAuthResult.Error(errorCode, errString.toString())
                }
            })
        prompt.authenticate(promptInfo)
    }
}
