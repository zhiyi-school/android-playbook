# platform-feature-05-risk-01-control-01

This is a minimal Android app that requires biometric verification before logging out, so an accessibility service cannot log the user out programmatically.

## Implemented Controls

- The Logout button calls `handleLogoutClick()`, which starts `initiateLogoutBiometricAuth()` when biometrics are available.
- `BiometricAuthManager` shows a `BiometricPrompt` (`BIOMETRIC_STRONG`) and publishes the result through `authenticationResult`.
- `performLogout()` only runs when the result is `Success`.
- Without enrolled biometrics, `showLogoutConfirmation()` shows an ordinary dialog, as in the playbook.

That fallback dialog can be clicked by an accessibility service. As the playbook's note says, a stronger fallback is the device credential (`BIOMETRIC_STRONG or DEVICE_CREDENTIAL`). Test the control on a device with and without biometrics enrolled.

## Run

Open this folder in Android Studio (2026.1 or later), connect a device and press Run. From the command line, with JDK 17 or later and `ANDROID_HOME` pointing at your Android SDK:

```bash
./gradlew installDebug
```

Built with Android Gradle Plugin 9.3.3, Gradle 9.8.2 (wrapper included) and compileSdk 37.
